---
title: অ্যাডভান্সড
weight: 20
menu:
  notes:
    name: অ্যাডভান্সড
    identifier: notes-go-advanced
    parent: notes-go
    weight: 20
---
