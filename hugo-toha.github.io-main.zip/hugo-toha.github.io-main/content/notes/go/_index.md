---
title: Go Notes
menu:
  notes:
    name: Go
    identifier: notes-go
    weight: 10
---

# Go Notes
