---
title: ব্যাশের নোট সমূহ
menu:
  notes:
    name: ব্যাশ
    identifier: notes-bash
    weight: 20
---
# Bash Notes