---
title: "সমৃদ্ধ কন্টেন্ট"
date: 2020-06-08T08:06:25+06:00
description: Sample post with multiple images, embedded video ect.
menu:
  sidebar:
    name: সমৃদ্ধ কন্টেন্ট
    identifier: rich-content
    parent: sub-category
    weight: 10
tags: ["মার্কডাউন","কন্টেন্ট সাজানো","বহুভাষিক"]
categories: ["বেসিক"]
---

এই নমুনা পোস্টটি এই বিষয়গুলো পরীক্ষা করার জন্যে করা হয়েছেঃ

- বিভাগ, উপ-বিভাগে সাইডবারে একটির ভেতর আরেকটি কিভাবে আছে সেটা দেখা।
- হেরো ছবিটি পোস্ট যে পথে আছে সে পথে `images` ফোল্ডার এ থাকবে।
- বিভিন্ন মিডিয়া যেমন ছবি, টুইট, ইউটিউব ভিডিও, ভীমেও ভিডিও ইত্যাদি রেন্ডারিং।

### ছবির নমুনা

{{< img src="/posts/category/sub-category/rich-content/images/forest.jpg" align="center" title="Forest" >}}

{{< vs >}}

### টুইটের নুমুনা

{{< tweet user="SanDiegoZoo" id="1453110110599868418" >}}

{{< vs >}}

### ইউটিওবের ভিডিও নমুনা

{{< youtube ZJthWmvUzzc >}}

{{< vs >}}

### ভীমেও ভিডিও নমুনা

{{< vimeo 48912912 >}}
